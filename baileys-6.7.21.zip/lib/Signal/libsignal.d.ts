import type { SignalAuthState } from '../Types/index.js';
import type { SignalRepository } from '../Types/Signal.js';
export declare function makeLibSignalRepository(auth: SignalAuthState): SignalRepository;
//# sourceMappingURL=libsignal.d.ts.map